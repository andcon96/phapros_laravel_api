<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Qxwsa extends Model
{
    use HasFactory;

    public $table = 'qxwsa';

    protected $fillable = [
        'id'
    ];
}
