<?php $__empty_1 = true; $__currentLoopData = $datamrp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datamrps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td data-title="Product Line"><?php echo e($datamrps['t_pt_prod_line']); ?></td>
        <td data-title="Order Type"><?php echo e($datamrps['t_mrp_type']); ?></td>
        <td data-title="Data Set"><?php echo e($datamrps['t_mrp_dataset']); ?></td>
        <td data-title="Item No"><?php echo e($datamrps['t_mrp_part']); ?></td>
        <td data-title="Description"><?php echo e($datamrps['t_partdesc']); ?></td>
        <td data-title="Batch (Order)"><?php echo e($datamrps['t_mrp_nbr']); ?></td>
        <td data-title="Quantity (Sched Rcpt)"><?php echo e($datamrps['t_mrp_qty']); ?></td>
        <td data-title="Quantity On Hand"><?php echo e($datamrps['t_ld_qty_oh']); ?></td>
        <td data-title="Status WO / PR"><?php echo e($datamrps['t_pt_pm_code']); ?></td>
        <td data-title="Released Date"><?php echo e($datamrps['t_mrp_rel_date']); ?></td>
        <td data-title="Due Date"><?php echo e($datamrps['t_mrp_due_date']); ?></td>
        <td data-title="Action Message"><?php echo e($datamrps['t_pt_ord_per']); ?></td>
        <td data-title="Order Period"><?php echo e($datamrps['t_pt_ord_mult']); ?></td>
        <td data-title="Order Multiple"><?php echo e($datamrps['t_pt_ord_min']); ?></td>
        <td data-title="Minimum Order"><?php echo e($datamrps['t_oa_det']); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td class="text-danger" colspan='15'>
            <center><b>No Data Available</b></center>
        </td>
    </tr>
<?php endif; ?>
<tr style="border:0 !important">
    <td colspan="12">
        <?php echo e($datamrp->withQueryString()->links()); ?>

    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\phapros_laravel_api\resources\views/transaksi/mrp/index-table.blade.php ENDPATH**/ ?>