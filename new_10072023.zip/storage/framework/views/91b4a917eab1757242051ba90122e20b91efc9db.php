<?php $__empty_1 = true; $__currentLoopData = $pomstr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pomstrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td data-title="Domain"><?php echo e($pomstrs->po_domain); ?></td>
        <td data-title="PO Number"><?php echo e($pomstrs->po_nbr); ?></td>
        <td data-title="Vendor"><?php echo e($pomstrs->po_vend); ?> -- <?php echo e($pomstrs->po_vend_desc); ?></td>
        <td data-title="Ship To"><?php echo e($pomstrs->po_ship); ?></td>
        <td data-title="Order Date"><?php echo e($pomstrs->po_ord_date); ?></td>
        <td data-title="Due Date"><?php echo e($pomstrs->po_due_date); ?></td>
        <td data-title="Status"><?php echo e($pomstrs->po_status); ?></td>
        <td data-title="Export">
            <a href="#" data-toggle="modal" data-target="#exportModal" class="viewreceipt"
                data-ponbr="<?php echo e($pomstrs->po_nbr); ?>" data-rcpdetail="<?php echo e($pomstrs->getHistoryReceipt); ?>">
                <i class="fa fa-file-pdf-o" style="color: red;"></i>
            </a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td class="text-danger" colspan='12'>
            <center><b>No Data Available</b></center>
        </td>
    </tr>
<?php endif; ?>
<tr style="border:0 !important">
    <td colspan="12">
        <?php echo e($pomstr->withQueryString()->links()); ?>

    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\phapros_laravel_api\resources\views/transaksi/po/index-table.blade.php ENDPATH**/ ?>