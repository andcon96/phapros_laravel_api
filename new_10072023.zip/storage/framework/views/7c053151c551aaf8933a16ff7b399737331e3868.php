<?php $__empty_1 = true; $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td class="text-center itemcode"><?php echo e($key); ?></td>
        <td class="text-center"><?php echo e($item['item_design_group']); ?></td>
        <td class="text-center"><?php echo e($item['item_description']); ?></td>
        <td class="text-center"><?php echo e($item['item_pareto']); ?></td>
        <td class="text-center"><?php echo e($item['item_make_to_type']); ?></td>
        <td class="text-center"><?php echo e(str_replace(',', '.', number_format($item['item_ed'], 0))); ?></td>
        <td class="text-center"><?php echo e(str_replace(',', '.', number_format($item['item_bv'], 0))); ?></td>
        <td class="text-center stockAkhir"><?php echo e(str_replace(',', '.', number_format($item['item_stock_qty_oh'], 0))); ?></td>

        <?php $__currentLoopData = $dataPerMonthAndYear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulanTahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="text-center kolomEstimasiStockAkhir<?= $key ?>">0</td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $item['forecast']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forecast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="text-center kolomForecast<?= $key ?>"><?php echo e($forecast['totalQty']); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $item['rencanaProduksi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rencanaProduksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="text-center nilaiRencanaProd kolomRencanaProd<?= $key ?>"
                style="cursor: pointer;text-decoration:none;"
                onmouseover="this.style.textDecoration='<?php echo e($rencanaProduksi == 0 ? '' : 'underline'); ?>';"
                onmouseout="this.style.textDecoration='none';" data-itemcode="<?php echo e($key); ?>"
                data-bulan="<?php echo e($rencanaProduksi['bulan']); ?>" data-tahun="<?php echo e($rencanaProduksi['tahun']); ?>"
                data-toggle="modal" data-target="#popUpRencanaProd">
                <?php echo e($rencanaProduksi['totalQty']); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="<?php echo e($totalPeriode == 0 ? 11 : $totalPeriode * 2 + 8); ?>"style="color:red">
            <center>No Data Available</center>
        </td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\phapros_laravel_api\resources\views/rencanaProduksi/table.blade.php ENDPATH**/ ?>