<?php $__empty_1 = true; $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td data-title="Name"><?php echo e($items->item_code); ?></td>
    <td data-title="Username"><?php echo e($items->item_desc); ?></td>
    <td data-title="Aksesweb"><?php echo e($items->item_rn); ?></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
  <td class="text-danger" colspan='12'>
    <center><b>No Data Available</b></center>
  </td>
</tr>
<?php endif; ?>
<tr style="border:0 !important">
  <td colspan="12">
    <?php echo e($item->withQueryString()->links()); ?>

  </td>
</tr>             
<?php /**PATH C:\xampp\htdocs\phapros_laravel_api\resources\views/setting/item/index-table.blade.php ENDPATH**/ ?>