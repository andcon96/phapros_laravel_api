

<?php $__env->startSection('breadcrumbs'); ?>
<ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\phapros_laravel_api\resources\views/home.blade.php ENDPATH**/ ?>