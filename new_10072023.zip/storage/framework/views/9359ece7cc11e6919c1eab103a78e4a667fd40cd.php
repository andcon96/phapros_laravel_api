

<?php $__env->startSection('content'); ?>
    
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Data PO
                </h5>
            </div>
            <div class="card-body">
                <div class="form-group row col-md-12">
                    <div class="form-group row col-md-12">
                        <label for="domain" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Domain')); ?></label>
                        <div class="col-md-4 col-lg-3">
                            <input id="domain" type="text" class="form-control" name="domain"
                                value="<?php echo e($receipt->getpo->po_domain ?? ''); ?>" readonly>
                        </div>
                        <label for="ponbr" class="col-md-2 col-form-label text-md-right"><?php echo e(__('PO Number')); ?></label>
                        <div class="col-md-4 col-lg-3">
                            <input id="ponbr" type="text" class="form-control" name="ponbr"
                                value="<?php echo e($receipt->getpo->po_nbr ?? ''); ?>" readonly>
                        </div>
                    </div>

                    <div class="form-group row col-md-12">
                        <label for="vendor" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Vendor')); ?></label>
                        <div class="col-md-4 col-lg-3">
                            <input id="vendor" type="text" class="form-control" name="vendor"
                                value="<?php echo e($receipt->getpo->po_vend ?? ''); ?> - <?php echo e($receipt->getpo->po_vend_desc ?? ''); ?>"
                                readonly>
                        </div>
                        <label for="shipto" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Ship To')); ?></label>
                        <div class="col-md-4 col-lg-3">
                            <input id="shipto" type="text" class="form-control" name="shipto"
                                value="<?php echo e($receipt->getpo->po_ship ?? ''); ?>" readonly>
                        </div>
                    </div>

                    <div class="form-group row col-md-12">
                        <label for="orddate" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Order Date')); ?></label>
                        <div class="col-md-4 col-lg-3">
                            <input id="orddate" type="text" class="form-control" name="orddate"
                                value="<?php echo e($receipt->getpo->po_ord_date ?? ''); ?>" readonly>
                        </div>
                        <label for="duedate" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Due Date')); ?></label>
                        <div class="col-md-4 col-lg-3">
                            <input id="duedate" type="text" class="form-control" name="duedate"
                                value="<?php echo e($receipt->getpo->po_due_date ?? ''); ?>" readonly>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Data Receipt
                </h5>
            </div>
            <div class="card-body">
                <div class="form-group row col-md-12">
                    <div class="form-group row col-md-12">
                        <label for="rcpnbr"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('Receipt Number')); ?></label>
                        <div class="col-md-8">
                            <input id="rcpnbr" type="text" class="form-control" name="rcpnbr"
                                value="<?php echo e($receipt->rcpt_nbr ?? ''); ?>" readonly>
                        </div>
                    </div>

                    <div class="form-group row col-md-12">
                        <label for="status" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Status')); ?></label>
                        <div class="col-md-8">
                            <input id="status" type="text" class="form-control" name="status"
                                value="<?php echo e(ucfirst($receipt->rcpt_status) ?? ''); ?>" readonly>
                        </div>
                    </div>

                    <div class="form-group row col-md-12">
                        <label for="createdby" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Created By')); ?></label>
                        <div class="col-md-8">
                            <input id="createdby" type="text" class="form-control" name="createdby"
                                value="<?php echo e($receipt->getUser->nama ?? ''); ?>" readonly>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Data Checklist
                </h5>
            </div>
            <div class="card-body">
                <div class="form-group row col-md-12">
                    <div class="form-group row col-md-12">
                        <label for="imrno" class="col-md-4 col-form-label text-md-right"><?php echo e(__('IMR No.')); ?></label>
                        <div class="col-md-8">
                            <input id="imrno" type="text" class="form-control" name="imrno"
                                value="<?php echo e($receipt->getChecklist->rcptc_imr_nbr ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="artno"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('Article No.')); ?></label>
                        <div class="col-md-8">
                            <input id="artno" type="text" class="form-control" name="artno"
                                value="<?php echo e($receipt->getChecklist->rcptc_article_nbr ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="imrdate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('IMR Date')); ?></label>
                        <div class="col-md-8">
                            <input id="imrdate" type="text" class="form-control" name="imrdate"
                                value="<?php echo e($receipt->getChecklist->rcptc_imr_date ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="arrdate"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('Arrival Date')); ?></label>
                        <div class="col-md-8">
                            <input id="arrdate" type="text" class="form-control" name="arrdate"
                                value="<?php echo e($receipt->getChecklist->rcptc_arrival_date ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="proddate"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('Production Date')); ?></label>
                        <div class="col-md-8">
                            <input id="proddate" type="text" class="form-control" name="proddate"
                                value="<?php echo e($receipt->getChecklist->rcptc_prod_date ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="expdate"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('Expiration Date')); ?></label>
                        <div class="col-md-8">
                            <input id="expdate" type="text" class="form-control" name="expdate"
                                value="<?php echo e($receipt->getChecklist->rcptc_exp_date ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="manu"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('Manufacturer')); ?></label>
                        <div class="col-md-8">
                            <input id="manu" type="text" class="form-control" name="manu"
                                value="<?php echo e($receipt->getChecklist->rcptc_manufacturer ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="country" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country')); ?></label>
                        <div class="col-md-8">
                            <input id="country" type="text" class="form-control" name="country"
                                value="<?php echo e($receipt->getChecklist->rcptc_country ?? ''); ?>" readonly>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Data Kemasan
                </h5>
            </div>
            <div class="card-body">
                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="sackdos"
                            <?php echo e($receipt->getKemasan->rcptk_kemasan_sacdos == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="sackdos">Kemasan Sack / Dos</label>
                    </div>
                </div>
                <div class="form-group row col-md-12">
                    <label for="ketsackdos" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                    <div class="col-md-8">
                        <input id="ketsackdos" type="text" class="form-control" name="ketsackdos"
                            value="<?php echo e($receipt->getKemasan->rcptk_kemasan_sacdos_desc ?? ''); ?>" readonly>
                    </div>
                </div>

                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="drumvat"
                            <?php echo e($receipt->getKemasan->rcptk_kemasan_drumvat == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="drumvat">Kemasan Drum / Vat</label>
                    </div>
                </div>
                <?php if($receipt->getKemasan->rcptk_kemasan_drumvat == 1): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketdrumvat"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketdrumvat" type="text" class="form-control" name="ketdrumvat"
                                value="<?php echo e($receipt->getKemasan->rcptk_kemasan_drumvat_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="paletpeti"
                            <?php echo e($receipt->getKemasan->rcptk_kemasan_palletpeti == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="paletpeti">Kemasan Pallet / Peti</label>
                    </div>
                </div>
                <?php if($receipt->getKemasan->rcptk_kemasan_palletpeti_desc == 1): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketpaletpeti"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketpaletpeti" type="text" class="form-control" name="ketpaletpeti"
                                value="<?php echo e($receipt->getKemasan->rcptk_kemasan_palletpeti_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                
                <div class="form-group col-md-12 text-center">
                    <hr style="width:100%;text-align:left;margin-left:0">
                    <h5>Kondisi</h5>
                    <hr style="width:100%;text-align:left;margin-left:0">
                </div>
                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12 mb-3">
                        <h5>Bersih</h5>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_clean == 1 ? 'checked' : ''); ?> disabled>Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_clean == 0 ? 'checked' : ''); ?> disabled>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($receipt->getKemasan->rcptk_is_clean_desc != null && $receipt->getKemasan->rcptk_is_clean_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisclean"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisclean" type="text" class="form-control" name="ketisclean"
                                value="<?php echo e($receipt->getKemasan->rcptk_is_clean_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12 mb-3">
                        <h5>Kering</h5>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_dry == 1 ? 'checked' : ''); ?> disabled>Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_dry == 0 ? 'checked' : ''); ?> disabled>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($receipt->getKemasan->rcptk_is_dry_desc != null && $receipt->getKemasan->rcptk_is_dry_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisdry"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisdry" type="text" class="form-control" name="ketisdry"
                                value="<?php echo e($receipt->getKemasan->rcptk_is_dry_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12 mb-3">
                        <h5>Tumpah</h5>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_not_spilled == 0 ? 'checked' : ''); ?> disabled>Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_not_spilled == 1 ? 'checked' : ''); ?> disabled>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($receipt->getKemasan->rcptk_is_not_spilled_desc != null && $receipt->getKemasan->rcptk_is_not_spilled_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisnotspilled"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisnotspilled" type="text" class="form-control" name="ketisnotspilled"
                                value="<?php echo e($receipt->getKemasan->rcptk_is_not_spilled_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                
                <div class="form-group col-md-12 text-center">
                    <hr style="width:100%;text-align:left;margin-left:0">
                    <h5>Segel</h5>
                    <hr style="width:100%;text-align:left;margin-left:0">
                </div>
                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_sealed == 0 ? 'checked' : ''); ?> disabled>Utuh
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_sealed == 1 ? 'checked' : ''); ?> disabled>Rusak
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="form-group col-md-12 text-center">
                    <hr style="width:100%;text-align:left;margin-left:0">
                    <h5>Label Pabrik</h5>
                    <hr style="width:100%;text-align:left;margin-left:0">
                </div>
                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_manufacturer_label == 0 ? 'checked' : ''); ?>

                                        disabled>Utuh
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getKemasan->rcptk_is_manufacturer_label == 1 ? 'checked' : ''); ?>

                                        disabled>Rusak
                                </label>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Data Angkutan
                </h5>
            </div>
            <div class="card-body">
                <div class="form-group row col-md-12">
                    <label for="transporter"
                        class="col-md-3 col-form-label text-md-right"><?php echo e(__('No. Transporter')); ?></label>
                    <div class="col-md-8">
                        <input id="transporter" type="text" class="form-control" name="transporter"
                            value="<?php echo e($receipt->getTransport->rcptt_transporter_no ?? ''); ?>" readonly>
                    </div>
                </div>
                <div class="form-group row col-md-12">
                    <label for="transporter" class="col-md-3 col-form-label text-md-right"><?php echo e(__('No. Polis')); ?></label>
                    <div class="col-md-8">
                        <input id="transporter" type="text" class="form-control" name="transporter"
                            value="<?php echo e($receipt->getTransport->rcptt_police_no ?? ''); ?>" readonly>
                    </div>
                </div>

                
                <div class="form-group col-md-12 text-center">
                    <hr style="width:100%;text-align:left;margin-left:0">
                    <h5>Kondisi</h5>
                    <hr style="width:100%;text-align:left;margin-left:0">
                </div>
                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12 mb-3">
                        <h5>Bersih</h5>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_clean == 1 ? 'checked' : ''); ?> disabled>Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_clean == 0 ? 'checked' : ''); ?> disabled>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($receipt->getTransport->rcptt_is_clean_desc != null && $receipt->getTransport->rcptt_is_clean_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisclean"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisclean" type="text" class="form-control" name="ketisclean"
                                value="<?php echo e($receipt->getTransport->rcptt_is_clean_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12 mb-3">
                        <h5>Kering</h5>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_dry == 1 ? 'checked' : ''); ?> disabled>Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_dry == 0 ? 'checked' : ''); ?> disabled>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($receipt->getTransport->rcptt_is_dry_desc != null && $receipt->getTransport->rcptt_is_dry_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisdry"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisdry" type="text" class="form-control" name="ketisdry"
                                value="<?php echo e($receipt->getTransport->rcptt_is_dry_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12 mb-3">
                        <h5>Tumpah</h5>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_not_spilled == 0 ? 'checked' : ''); ?>

                                        disabled>Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_not_spilled == 1 ? 'checked' : ''); ?>

                                        disabled>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(
                    $receipt->getTransport->rcptt_is_not_spilled_desc != null &&
                        $receipt->getTransport->rcptt_is_not_spilled_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisnotspilled"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisnotspilled" type="text" class="form-control" name="ketisnotspilled"
                                value="<?php echo e($receipt->getTransport->rcptt_is_not_spilled_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                
                <div class="form-group col-md-12 text-center">
                    <hr style="width:100%;text-align:left;margin-left:0">
                    <h5>Posisi Material</h5>
                    <hr style="width:100%;text-align:left;margin-left:0">
                </div>
                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_position_single == 0 ? 'checked' : ''); ?>

                                        disabled>Single
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_position_single == 1 ? 'checked' : ''); ?>

                                        disabled>Kombinasi
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(
                    $receipt->getTransport->rcptt_is_position_single_desc != null &&
                        $receipt->getTransport->rcptt_is_position_single_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisnotspilled"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisnotspilled" type="text" class="form-control" name="ketisnotspilled"
                                value="<?php echo e($receipt->getTransport->rcptt_is_position_single_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                
                <div class="form-group col-md-12 text-center">
                    <hr style="width:100%;text-align:left;margin-left:0">
                    <h5>Segregasi</h5>
                    <hr style="width:100%;text-align:left;margin-left:0">
                </div>
                <div class="form-group col-md-12 text-center">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_segregated == 1 ? 'checked' : ''); ?>

                                        disabled>Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"
                                        <?php echo e($receipt->getTransport->rcptt_is_segregated == 0 ? 'checked' : ''); ?> disabled>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($receipt->getTransport->rcptt_is_segregated_desc != null && $receipt->getTransport->rcptt_is_segregated_desc != ''): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketisnotspilled"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketisnotspilled" type="text" class="form-control" name="ketisnotspilled"
                                value="<?php echo e($receipt->getTransport->rcptt_is_segregated_desc ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>


            </div>
        </div>
    </div>

    
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Data Dokumen
                </h5>
            </div>
            <div class="card-body">

                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="coa"
                            <?php echo e($receipt->getDocument->rcptdoc_is_certofanalys == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="coa">Certificate Of Analysis</label>
                    </div>
                </div>
                <?php if($receipt->getDocument->rcptdoc_is_certofanalys == 1): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketcoa"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketcoa" type="text" class="form-control" name="ketcoa"
                                value="<?php echo e($receipt->getDocument->rcptdoc_certofanalys ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="msds"
                            <?php echo e($receipt->getDocument->rcptdoc_is_msds == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="msds">MSDS</label>
                    </div>
                </div>
                <?php if($receipt->getDocument->rcptdoc_is_msds == 1): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketmsds"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketmsds" type="text" class="form-control" name="ketmsds"
                                value="<?php echo e($receipt->getDocument->rcptdoc_msds ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="forwarderdo"
                            <?php echo e($receipt->getDocument->rcptdoc_is_forwarderdo == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="forwarderdo">Forwarder DO</label>
                    </div>
                </div>
                <?php if($receipt->getDocument->rcptdoc_is_forwarderdo == 1): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketforwarderdo"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketforwarderdo" type="text" class="form-control" name="ketforwarderdo"
                                value="<?php echo e($receipt->getDocument->rcptdoc_forwarderdo ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="packinglist"
                            <?php echo e($receipt->getDocument->rcptdoc_is_packinglist == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="packinglist">Packing List</label>
                    </div>
                </div>
                <?php if($receipt->getDocument->rcptdoc_is_packinglist == 1): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketpackinglist"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketpackinglist" type="text" class="form-control" name="ketpackinglist"
                                value="<?php echo e($receipt->getDocument->rcptdoc_packinglist ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group row col-md-12">
                    <div class="form-check mb-2">
                        <input type="checkbox" class="form-check-input" id="otherdocs"
                            <?php echo e($receipt->getDocument->rcptdoc_is_otherdocs == 1 ? 'checked' : ''); ?> disabled>
                        <label class="form-check-label" for="otherdocs">Other Docs</label>
                    </div>
                </div>
                <?php if($receipt->getDocument->rcptdoc_is_otherdocs == 1): ?>
                    <div class="form-group row col-md-12">
                        <label for="ketotherdocs"
                            class="col-md-3 col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>
                        <div class="col-md-8">
                            <input id="ketotherdocs" type="text" class="form-control" name="ketotherdocs"
                                value="<?php echo e($receipt->getDocument->rcptdoc_otherdocs ?? ''); ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Catatan
                </h5>
            </div>
            <div class="card-body">
                <div class="form-group row col-md-12">
                    <label for="rcpnbr" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Catatan')); ?></label>
                    <div class="col-md-8">
                        <input id="rcpnbr" type="text" class="form-control" name="rcpnbr"
                            value="<?php echo e($receipt->getTransport->rcptt_angkutan_catatan ?? ''); ?>" readonly>
                    </div>
                </div>
                <div class="form-group row col-md-12">
                    <label for="rcpnbr" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kelembapan')); ?></label>
                    <div class="col-md-8">
                        <input id="rcpnbr" type="text" class="form-control" name="rcpnbr"
                            value="<?php echo e($receipt->getTransport->rcptt_kelembapan ?? ''); ?>" readonly>
                    </div>
                </div>

                <div class="form-group row col-md-12">
                    <label for="rcpnbr" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Suhu')); ?></label>
                    <div class="col-md-8">
                        <input id="rcpnbr" type="text" class="form-control" name="rcpnbr"
                            value="<?php echo e($receipt->getTransport->rcptt_suhu ?? ''); ?>" readonly>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    Data Detail Receipt
                </h5>
            </div>
            <div class="card-body">
                <div class="form-group row col-md-12">
                    <div class="col-lg-12">
                        <div class="table-responsive">
                            <table class="table table-sm mb-0 table-striped"
                                style="overflow: scroll; white-space:nowrap;">
                                <thead>
                                    <tr>
                                        <th width="12%">Line</th>
                                        <th width="25%">Part</th>
                                        <th width="12%">UM</th>
                                        <th width="12%">Qty Per Package</th>
                                        <th width="12%">Qty Arrival</th>
                                        <th width="12%">Qty Approved</th>
                                        <th width="12%">Qty Reject</th>
                                        <th width="12%">Location</th>
                                        <th width="12%">Lot</th>
                                        <th width="12%">Batch</th>
                                        <th width="12%">Expiration Date</th>
                                        <th width="12%">Manufacturer Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $receipt->getDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row->rcptd_line); ?></td>
                                            <td><?php echo e($row->rcptd_part); ?> - <?php echo e($row->rcptd_part_desc); ?></td>
                                            <td><?php echo e($row->rcptd_part_um); ?></td>
                                            <td><?php echo e($row->rcptd_qty_per_package); ?></td>
                                            <td><?php echo e($row->rcptd_qty_arr); ?></td>
                                            <td><?php echo e($row->rcptd_qty_appr); ?></td>
                                            <td><?php echo e($row->rcptd_qty_rej); ?></td>
                                            <td><?php echo e($row->rcptd_loc); ?></td>
                                            <td><?php echo e($row->rcptd_lot); ?></td>
                                            <td><?php echo e($row->rcptd_batch); ?></td>
                                            <td><?php echo e($row->rcptd_exp_date); ?></td>
                                            <td><?php echo e($row->rcptd_manu_date); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 mb-4">
                    <a href="<?php echo e(route('purchaseorder.index')); ?>" class="btn btn-outline-secondary"><span class="btn btn-icon-left text-secondary"><i
                        class="fa fa-arrow-left"></i>
                </span>Back</a>
                </div>
            </div>
        </div>
    </div>

    <div id="loader" class="lds-dual-ring hidden overlay"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\phapros_laravel_api\resources\views/transaksi/po/receipt/detail-receipt.blade.php ENDPATH**/ ?>